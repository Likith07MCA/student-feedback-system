const express = require("express");
const Feedback = require("../models/Feedback");
const { authenticate, requireAdmin } = require("../middleware/auth");
const router = express.Router();

router.post("/", authenticate, async (req, res) => {
  try {
    if (req.user.role !== "student") return res.status(403).json({ message: "Only student accounts can submit feedback." });
    const course = String(req.body.course || "").trim();
    const comments = String(req.body.comments || "").trim();
    const rating = Number(req.body.rating);
    if (!course || !comments || !Number.isInteger(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({ message: "Select a course, enter comments, and choose a rating from 1 to 5." });
    }
    const feedback = await Feedback.create({
      student: req.user.id, studentName: req.user.name, course, rating, comments
    });
    res.status(201).json({ message: "Feedback submitted successfully.", feedback });
  } catch {
    res.status(500).json({ message: "Could not submit feedback." });
  }
});

router.get("/mine", authenticate, async (req, res) => {
  try {
    const feedback = await Feedback.find({ student: req.user.id }).sort({ createdAt: -1 });
    res.json({ feedback });
  } catch {
    res.status(500).json({ message: "Could not load your feedback." });
  }
});

router.get("/", authenticate, requireAdmin, async (req, res) => {
  try {
    const filter = {};
    if (req.query.course) filter.course = req.query.course;
    if (req.query.rating) filter.rating = Number(req.query.rating);
    if (req.query.search) {
      const search = String(req.query.search).trim();
      filter.$or = [
        { studentName: { $regex: search, $options: "i" } },
        { course: { $regex: search, $options: "i" } },
        { comments: { $regex: search, $options: "i" } }
      ];
    }
    const feedback = await Feedback.find(filter).sort({ createdAt: -1 });
    res.json({ feedback });
  } catch {
    res.status(500).json({ message: "Could not load feedback reports." });
  }
});

module.exports = router;
