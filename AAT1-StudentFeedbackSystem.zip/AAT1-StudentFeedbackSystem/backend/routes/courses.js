const express = require("express");
const { authenticate } = require("../middleware/auth");
const router = express.Router();

const courses = [
  "Web Development",
  "Database Management Systems",
  "Computer Networks",
  "Data Structures",
  "Artificial Intelligence",
  "Software Engineering"
];

router.get("/", authenticate, (req, res) => res.json({ courses }));
module.exports = router;
