require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/student_feedback_system");
    const email = (process.env.ADMIN_EMAIL || "admin@feedback.com").toLowerCase();
    const password = process.env.ADMIN_PASSWORD || "Admin@12345678";
    const name = process.env.ADMIN_NAME || "System Administrator";
    if (password.length < 12) throw new Error("ADMIN_PASSWORD must be at least 12 characters.");
    const hash = await bcrypt.hash(password, 12);
    await User.findOneAndUpdate(
      { email },
      { $set: { name, email, password: hash, role: "admin" } },
      { upsert: true, new: true, runValidators: true }
    );
    console.log(`Admin account ready: ${email}`);
  } catch (error) {
    console.error("Could not create admin:", error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}
seed();
