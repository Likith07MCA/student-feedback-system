const mongoose = require("mongoose");

const feedbackSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  studentName: { type: String, required: true },
  course: { type: String, required: true, trim: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comments: { type: String, required: true, trim: true, maxlength: 1000 }
}, { timestamps: true });

module.exports = mongoose.model("Feedback", feedbackSchema);
