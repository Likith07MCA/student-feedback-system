# AAT-I Online Student Feedback System

A full-stack prototype built with React, Node.js, Express, and MongoDB.

## Features
- Student registration and login
- Course selection
- Feedback submission with a 1–5 rating and comments
- Admin login and feedback dashboard
- Search/filter feedback by course and rating
- GitHub-ready project structure

## Requirements
- Node.js 18+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- Git (for the GitHub assignment)

## 1. Configure the backend
Open a terminal in `backend` and run:
```bash
npm install
```
Copy `.env.example` to `.env` and edit it if needed. The default MongoDB URL is:
`mongodb://127.0.0.1:27017/student_feedback_system`

Set a long `JWT_SECRET` and change the default admin password before using this beyond a local demo.

## 2. Create the admin account
In the `backend` folder:
```bash
npm run seed-admin
```
Default demo credentials:
- Email: `admin@feedback.com`
- Password: `Admin@12345678`

Change these values in `backend/.env` before running the seed command if desired.

## 3. Start the backend
In the `backend` folder:
```bash
npm run dev
```
API runs at `http://localhost:5000`.

## 4. Start the frontend
Open a second terminal in `frontend`:
```bash
npm install
npm run dev
```
Open the URL printed by Vite, usually `http://localhost:5173`.

## 5. GitHub assignment checklist
1. Create an empty GitHub repository.
2. `git init`
3. `git add .`
4. `git commit -m "Initial commit"`
5. Add remote and `git push -u origin main`
6. Create a feature branch with `git switch -c feature/feedback-improvements`
7. Commit a small change on the branch and push it.
8. Merge the branch into `main`.
9. Add/update `README.md`.
10. Create an Issue and a Pull Request on GitHub.

Do not commit your real `.env` file or secrets.
