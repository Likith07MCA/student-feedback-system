import { useEffect, useMemo, useState } from "react";
import { BookOpen, GraduationCap, LogOut, MessageSquareText, Search, ShieldCheck, Star, Users, BarChart3, Send, LockKeyhole } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const COURSES = ["Web Development", "Database Management Systems", "Computer Networks", "Data Structures", "Artificial Intelligence", "Software Engineering"];

async function request(path, options = {}) {
  const token = localStorage.getItem("sfsToken");
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}

export default function App() {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("sfsUser") || "null"); } catch { return null; }
  });
  const [authMode, setAuthMode] = useState("login");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
  const [course, setCourse] = useState(COURSES[0]);
  const [rating, setRating] = useState(5);
  const [comments, setComments] = useState("");
  const [mine, setMine] = useState([]);
  const [allFeedback, setAllFeedback] = useState([]);
  const [search, setSearch] = useState("");
  const [filterCourse, setFilterCourse] = useState("");
  const [filterRating, setFilterRating] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const logout = () => {
    localStorage.removeItem("sfsToken");
    localStorage.removeItem("sfsUser");
    setUser(null); setMine([]); setAllFeedback([]); setNotice(""); setError("");
  };

  const loadStudentFeedback = async () => {
    try { const data = await request("/feedback/mine"); setMine(data.feedback || []); }
    catch (e) { setError(e.message); }
  };

  const loadAdminFeedback = async () => {
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("search", search.trim());
      if (filterCourse) params.set("course", filterCourse);
      if (filterRating) params.set("rating", filterRating);
      const data = await request(`/feedback?${params.toString()}`);
      setAllFeedback(data.feedback || []);
    } catch (e) { setError(e.message); }
  };

  useEffect(() => {
    if (!user) return;
    if (user.role === "admin") loadAdminFeedback();
    else loadStudentFeedback();
  }, [user]);

  useEffect(() => {
    if (!user || user.role !== "admin") return;
    const timer = setTimeout(loadAdminFeedback, 250);
    return () => clearTimeout(timer);
  }, [search, filterCourse, filterRating, user]);

  const submitAuth = async (event) => {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const endpoint = authMode === "register" ? "/auth/register" : "/auth/login";
      const data = await request(endpoint, { method: "POST", body: JSON.stringify(authForm) });
      if (authMode === "register") {
        setNotice(data.message); setAuthMode("login"); setAuthForm({ name: "", email: authForm.email, password: "" });
      } else {
        localStorage.setItem("sfsToken", data.token);
        localStorage.setItem("sfsUser", JSON.stringify(data.user));
        setUser(data.user); setNotice(`Welcome, ${data.user.name}!`);
      }
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  const submitFeedback = async (event) => {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const data = await request("/feedback", { method: "POST", body: JSON.stringify({ course, rating, comments }) });
      setNotice(data.message); setComments(""); setRating(5); await loadStudentFeedback();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  const stats = useMemo(() => {
    const total = allFeedback.length;
    const avg = total ? (allFeedback.reduce((sum, item) => sum + item.rating, 0) / total).toFixed(1) : "0.0";
    const students = new Set(allFeedback.map(item => item.student?.toString() || item.studentName)).size;
    return { total, avg, students };
  }, [allFeedback]);

  const exportCsv = () => {
    const rows = [["Student", "Course", "Rating", "Comments", "Submitted"]];
    allFeedback.forEach(f => rows.push([f.studentName, f.course, f.rating, f.comments, new Date(f.createdAt).toLocaleString()]));
    const csv = rows.map(row => row.map(v => `"${String(v ?? "").replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
    const a = document.createElement("a"); a.href = url; a.download = "student-feedback-report.csv"; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={e => e.preventDefault()}>
          <span className="brand-mark"><GraduationCap size={23} /></span>
          <span><strong>CampusVoice</strong><small>STUDENT FEEDBACK PORTAL</small></span>
        </a>
        {user && <div className="top-user"><span className="avatar">{(user.name || "U").charAt(0).toUpperCase()}</span><span className="user-name">{user.name}<small>{user.role === "admin" ? "Administrator" : "Student account"}</small></span><button className="btn btn-quiet" onClick={logout}><LogOut size={16}/> Logout</button></div>}
      </header>

      {!user ? (
        <main className="auth-layout">
          <section className="welcome-panel">
            <div className="eyebrow"><span className="eyebrow-dot"/> YOUR VOICE SHAPES OUR CAMPUS</div>
            <h1>Better learning<br/>starts with <em>your feedback.</em></h1>
            <p>A simple, secure space to share your learning experience and help make every course better.</p>
            <div className="welcome-points"><div><span className="point-icon"><BookOpen size={19}/></span><span><b>Share your experience</b><small>Give feedback on the courses you take.</small></span></div><div><span className="point-icon"><ShieldCheck size={19}/></span><span><b>Your voice matters</b><small>Your feedback helps improve teaching.</small></span></div></div>
            <div className="welcome-foot">AAT-I PROJECT <span>•</span> ONLINE STUDENT FEEDBACK SYSTEM</div>
          </section>
          <section className="auth-side">
            <form className="auth-card" onSubmit={submitAuth}>
              <div className="card-icon"><LockKeyhole size={22}/></div>
              <h2>{authMode === "login" ? "Welcome back" : "Create your account"}</h2>
              <p className="muted">{authMode === "login" ? "Sign in to continue to your portal." : "Register as a student to share feedback."}</p>
              {authMode === "register" && <label>Full name<input required value={authForm.name} onChange={e => setAuthForm({ ...authForm, name: e.target.value })} placeholder="Your full name"/></label>}
              <label>Email address<input required type="email" value={authForm.email} onChange={e => setAuthForm({ ...authForm, email: e.target.value })} placeholder="you@example.com"/></label>
              <label>Password<input required minLength={8} type="password" value={authForm.password} onChange={e => setAuthForm({ ...authForm, password: e.target.value })} placeholder="At least 8 characters"/></label>
              {error && <div className="alert error">{error}</div>}{notice && <div className="alert success">{notice}</div>}
              <button className="btn btn-primary full" disabled={busy}>{busy ? "Please wait..." : authMode === "login" ? "Sign in" : "Create account"} <span>→</span></button>
              <div className="switch-auth">{authMode === "login" ? "New to CampusVoice?" : "Already registered?"} <button type="button" onClick={() => {setAuthMode(authMode === "login" ? "register" : "login"); setError(""); setNotice("");}}>{authMode === "login" ? "Create an account" : "Sign in"}</button></div>
              <div className="admin-hint">Administrator? Sign in using your admin account.</div>
            </form>
          </section>
        </main>
      ) : user.role === "admin" ? (
        <main className="dashboard">
          <div className="page-heading"><div><div className="eyebrow">ADMINISTRATION</div><h1>Feedback overview</h1><p className="muted">Review student responses and track the learning experience.</p></div><button className="btn btn-outline" onClick={exportCsv}><BarChart3 size={17}/> Export report</button></div>
          {notice && <div className="alert success">{notice}</div>}{error && <div className="alert error">{error}</div>}
          <div className="stats-grid"><Stat icon={<MessageSquareText/>} label="Feedback responses" value={stats.total} tone="blue"/><Stat icon={<Star/>} label="Average rating" value={`${stats.avg} / 5`} tone="gold"/><Stat icon={<Users/>} label="Student contributors" value={stats.students} tone="green"/></div>
          <section className="panel">
            <div className="panel-heading"><div><h2>Submitted feedback</h2><p className="muted">Search and filter responses.</p></div><span className="count-pill">{allFeedback.length} records</span></div>
            <div className="filters"><div className="search-field"><Search size={17}/><input placeholder="Search name, course or comment..." value={search} onChange={e => setSearch(e.target.value)}/></div><select value={filterCourse} onChange={e => setFilterCourse(e.target.value)}><option value="">All courses</option>{COURSES.map(c => <option key={c}>{c}</option>)}</select><select value={filterRating} onChange={e => setFilterRating(e.target.value)}><option value="">All ratings</option>{[5,4,3,2,1].map(n => <option key={n} value={n}>{n} stars</option>)}</select></div>
            <FeedbackTable feedback={allFeedback}/>
          </section>
        </main>
      ) : (
        <main className="dashboard student-dashboard">
          <div className="page-heading"><div><div className="eyebrow">STUDENT PORTAL</div><h1>Welcome, {user.name.split(" ")[0]}</h1><p className="muted">Your thoughts help shape a better learning experience.</p></div><div className="student-badge"><GraduationCap size={18}/> Student workspace</div></div>
          {notice && <div className="alert success">{notice}</div>}{error && <div className="alert error">{error}</div>}
          <div className="student-grid">
            <section className="panel feedback-panel"><div className="panel-heading"><div><h2>Share your feedback</h2><p className="muted">Tell us how your course is going.</p></div><span className="panel-symbol"><MessageSquareText size={20}/></span></div>
              <form onSubmit={submitFeedback}>
                <label>Course<select required value={course} onChange={e => setCourse(e.target.value)}>{COURSES.map(c => <option key={c}>{c}</option>)}</select></label>
                <label>Your rating</label><div className="rating-picker">{[1,2,3,4,5].map(n => <button type="button" aria-label={`${n} stars`} key={n} onClick={() => setRating(n)} className={n <= rating ? "star active" : "star"}><Star size={27} fill={n <= rating ? "currentColor" : "none"}/></button>)}<span>{rating === 5 ? "Excellent" : rating === 4 ? "Very good" : rating === 3 ? "Good" : rating === 2 ? "Fair" : "Needs improvement"}</span></div>
                <label>Comments<textarea required maxLength={1000} rows={5} value={comments} onChange={e => setComments(e.target.value)} placeholder="What worked well? What could be improved?"/></label>
                <div className="form-foot"><small>{comments.length}/1000 characters</small><button className="btn btn-primary" disabled={busy}><Send size={16}/>{busy ? "Submitting..." : "Submit feedback"}</button></div>
              </form>
            </section>
            <section className="panel history-panel"><div className="panel-heading"><div><h2>Your submissions</h2><p className="muted">Feedback you've shared so far.</p></div><span className="count-pill">{mine.length}</span></div>{mine.length ? <div className="history-list">{mine.map(f => <article className="history-item" key={f._id}><div className="history-top"><b>{f.course}</b><span className="rating-small"><Star size={13} fill="currentColor"/> {f.rating}.0</span></div><p>{f.comments}</p><small>{new Date(f.createdAt).toLocaleDateString()}</small></article>)}</div> : <div className="empty-state"><span><MessageSquareText size={25}/></span><b>No feedback yet</b><p>Your submitted responses will appear here.</p></div>}</section>
          </div>
        </main>
      )}
      <footer className="footer"><span>CampusVoice</span><span>Online Student Feedback System <i>•</i> AAT-I</span></footer>
    </div>
  );
}

function Stat({ icon, label, value, tone }) {
  return <div className="stat-card"><span className={`stat-icon ${tone}`}>{icon}</span><div><small>{label}</small><strong>{value}</strong></div></div>;
}

function FeedbackTable({ feedback }) {
  if (!feedback.length) return <div className="empty-state table-empty"><span><Search size={24}/></span><b>No matching feedback</b><p>Try changing your search or filters.</p></div>;
  return <div className="table-wrap"><table><thead><tr><th>STUDENT</th><th>COURSE</th><th>RATING</th><th>COMMENTS</th><th>SUBMITTED</th></tr></thead><tbody>{feedback.map(f => <tr key={f._id}><td><div className="student-cell"><span className="mini-avatar">{(f.studentName || "S").charAt(0).toUpperCase()}</span><b>{f.studentName}</b></div></td><td>{f.course}</td><td><span className="rating-small"><Star size={13} fill="currentColor"/> {f.rating}.0</span></td><td className="comment-cell">{f.comments}</td><td className="date-cell">{new Date(f.createdAt).toLocaleDateString()}</td></tr>)}</tbody></table></div>;
}
